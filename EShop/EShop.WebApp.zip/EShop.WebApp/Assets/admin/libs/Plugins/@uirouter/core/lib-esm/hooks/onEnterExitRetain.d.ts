import { TransitionService } from '../transition/transitionService';
export declare const registerOnExitHook: (transitionService: TransitionService) => Function;
export declare const registerOnRetainHook: (transitionService: TransitionService) => Function;
export declare const registerOnEnterHook: (transitionService: TransitionService) => Function;
