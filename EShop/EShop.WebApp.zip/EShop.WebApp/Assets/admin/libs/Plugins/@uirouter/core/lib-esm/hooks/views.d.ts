import { TransitionService } from '../transition/transitionService';
export declare const registerLoadEnteringViews: (transitionService: TransitionService) => Function;
export declare const registerActivateViews: (transitionService: TransitionService) => Function;
