/** @internalapi @module hooks */ /** */
import { TransitionService } from '../transition/transitionService';
export declare const registerInvalidTransitionHook: (transitionService: TransitionService) => Function;
