/** @internalapi @module hooks */ /** */
import { TransitionService } from '../transition/transitionService';
export declare const registerIgnoredTransitionHook: (transitionService: TransitionService) => Function;
