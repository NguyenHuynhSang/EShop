export declare const safeConsole: {
    log: any;
    error: any;
    table: any;
};
