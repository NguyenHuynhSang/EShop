/** @hidden */ export declare const ng: any;
