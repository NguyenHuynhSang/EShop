﻿

(function (app) {

    app.controller('home-controller',homeController)
    function homeController() {


    }
})(angular.module('eshop'));
