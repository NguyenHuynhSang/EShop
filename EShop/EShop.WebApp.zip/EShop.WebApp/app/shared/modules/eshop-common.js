﻿
(function () {
    /*
    * inject các module dùng chung
    * */
    angular.module('eshop-common', ['ui.router', 'ngBootbox', 'ng.ckeditor','ui.tree'])

})();
